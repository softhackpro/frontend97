"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  CheckCircle,
  CalendarIcon,
  Camera,
  Star,
  Users,
  Clock,
  MapPin,
  Mail,
  Upload,
  Shield,
  Edit,
  Plus,
} from "lucide-react"

export default function ProfilePage() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="container mx-auto py-6 max-w-6xl">
      {/* Profile Header */}
      <div className="relative mb-8">
        {/* Cover Photo */}
        <div className="h-48 w-full rounded-xl bg-gradient-to-r from-teal-500 to-blue-500 relative">
          <Button variant="ghost" size="icon" className="absolute top-4 right-4 bg-white/20 hover:bg-white/40">
            <Edit className="h-4 w-4" />
          </Button>
        </div>

        {/* Profile Picture and Basic Info */}
        <div className="flex flex-col md:flex-row gap-6 px-4">
          <div className="flex flex-col items-center -mt-16">
            <div className="relative">
              <Avatar className="h-32 w-32 border-4 border-white">
                <AvatarImage src="/placeholder.svg?height=128&width=128" alt="Sarah A." />
                <AvatarFallback>SA</AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1">
                <Badge className="bg-green-500 text-white border-2 border-white rounded-full p-1">
                  <CheckCircle className="h-4 w-4" />
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 flex items-center gap-1 text-xs"
              >
                <Camera className="h-3 w-3" />
                <span>Update</span>
              </Button>
            </div>
            <div className="mt-6 flex flex-col items-center">
              <Button variant="outline" size="sm" className="mb-2">
                <Shield className="h-4 w-4 mr-1" />
                Verify Identity
              </Button>
              <div className="text-xs text-muted-foreground">Take a selfie with a wink or wave</div>
            </div>
          </div>

          <div className="flex-1 pt-4 md:pt-0">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold">Sarah A.</h1>
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    Verified
                  </Badge>
                </div>
                <p className="text-muted-foreground">UX Designer & Creative Explorer</p>
              </div>
              <Button className="mt-2 md:mt-0">
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 mt-4">
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                94105
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mr-1" />
                27 years old • Female
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Mail className="h-4 w-4 mr-1" />
                sarah@example.com
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <Card className="bg-purple-50">
                <CardContent className="p-4 flex flex-col items-center">
                  <div className="text-xl font-bold text-purple-600">95%</div>
                  <div className="text-xs text-center">RSVP Attendance</div>
                  <div className="text-[10px] text-muted-foreground">190/200 events attended</div>
                </CardContent>
              </Card>
              <Card className="bg-green-50">
                <CardContent className="p-4 flex flex-col items-center">
                  <div className="text-xl font-bold text-green-600">1.2k</div>
                  <div className="text-xs text-center">Friends</div>
                </CardContent>
              </Card>
              <Card className="bg-amber-50">
                <CardContent className="p-4 flex flex-col items-center">
                  <div className="text-xl font-bold text-amber-600">15</div>
                  <div className="text-xs text-center">Squads</div>
                </CardContent>
              </Card>
              <Card className="bg-blue-50">
                <CardContent className="p-4 flex flex-col items-center">
                  <div className="text-xl font-bold text-blue-600">50</div>
                  <div className="text-xs text-center">Organizers</div>
                  <div className="text-[10px] text-muted-foreground">Connected event hosts</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="about" className="w-full">
        <TabsList className="grid grid-cols-6 mb-8">
          <TabsTrigger value="about">About</TabsTrigger>
          <TabsTrigger value="availability">Availability</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="squads">Squads</TabsTrigger>
          <TabsTrigger value="connections">Connections</TabsTrigger>
          <TabsTrigger value="photos">Photos</TabsTrigger>
        </TabsList>

        {/* About Tab */}
        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                About Me
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p>
                  Passionate UX designer with a love for creating intuitive and beautiful digital experiences. When I'm
                  not designing, you'll find me exploring local coffee shops, practicing yoga, or capturing moments
                  through my camera lens. Always eager to connect with fellow creatives and tech enthusiasts!
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Personality</h4>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">ENFJ</Badge>
                  <span className="text-sm text-muted-foreground">The Protagonist</span>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h4 className="font-medium">Tags & Interests</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">UX Design</Badge>
                  <Badge variant="outline">Photography</Badge>
                  <Badge variant="outline">Yoga</Badge>
                  <Badge variant="outline">Coffee</Badge>
                  <Badge variant="outline">Travel</Badge>
                  <Badge variant="outline">Tech</Badge>
                  <Badge variant="outline">Art</Badge>
                  <Badge variant="outline">Hiking</Badge>
                  <Button variant="ghost" size="sm" className="h-6 rounded-full">
                    <Plus className="h-3 w-3 mr-1" /> Add
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h4 className="font-medium">Professional Interests</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="flex items-center gap-2 p-2 rounded-md bg-blue-50">
                    <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                    <span>User Experience</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 rounded-md bg-blue-50">
                    <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                    <span>Visual Design</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 rounded-md bg-blue-50">
                    <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                    <span>Interaction Design</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 rounded-md bg-blue-50">
                    <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                    <span>Product Strategy</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Availability Tab */}
        <TabsContent value="availability" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalendarIcon className="h-5 w-5 mr-2" />
                Weekly Availability
              </CardTitle>
              <CardDescription>Set your weekly availability for Squad events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1">
                  <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
                </div>
                <div className="flex-1">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Connected Calendars</h4>
                      <Button variant="outline" size="sm">
                        <Plus className="h-4 w-4 mr-1" />
                        Connect
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-2 rounded-md border">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-2">
                            G
                          </div>
                          <div>
                            <div className="text-sm font-medium">Google Calendar</div>
                            <div className="text-xs text-muted-foreground">Connected • Do not share details</div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          Disconnect
                        </Button>
                      </div>

                      <div className="flex items-center justify-between p-2 rounded-md border">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 mr-2">
                            A
                          </div>
                          <div>
                            <div className="text-sm font-medium">Apple Calendar</div>
                            <div className="text-xs text-muted-foreground">Not connected</div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          Connect
                        </Button>
                      </div>

                      <div className="flex items-center justify-between p-2 rounded-md border">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-teal-100 flex items-center justify-center text-teal-600 mr-2">
                            C
                          </div>
                          <div>
                            <div className="text-sm font-medium">Calendly</div>
                            <div className="text-xs text-muted-foreground">Not connected</div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          Connect
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Events Tab */}
        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CalendarIcon className="h-5 w-5 mr-2" />
                Event History
              </CardTitle>
              <CardDescription>Events you've created and attended</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="attended">
                <TabsList className="mb-4">
                  <TabsTrigger value="attended">Attended</TabsTrigger>
                  <TabsTrigger value="created">Created</TabsTrigger>
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                </TabsList>

                <TabsContent value="attended" className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium">Event Attendance</h4>
                      <div className="text-sm text-muted-foreground">You've attended 190 out of 200 events</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">No-Show Rate: 5%</div>
                      <Progress value={5} className="w-32 h-2" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between p-3 rounded-md border">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 rounded-md bg-gray-100"></div>
                          <div>
                            <div className="font-medium">UX Design Workshop #{i}</div>
                            <div className="text-xs text-muted-foreground">March {10 + i}, 2023 • San Francisco</div>
                          </div>
                        </div>
                        <Badge>Attended</Badge>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="created" className="space-y-4">
                  <div className="text-center py-8 text-muted-foreground">
                    <div className="mb-2">You haven't created any events yet</div>
                    <Button>Create an Event</Button>
                  </div>
                </TabsContent>

                <TabsContent value="upcoming" className="space-y-4">
                  <div className="space-y-2">
                    {[1, 2].map((i) => (
                      <div key={i} className="flex items-center justify-between p-3 rounded-md border">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 rounded-md bg-gray-100"></div>
                          <div>
                            <div className="font-medium">Tech Meetup #{i}</div>
                            <div className="text-xs text-muted-foreground">April {5 + i}, 2023 • San Francisco</div>
                          </div>
                        </div>
                        <Badge variant="outline">RSVP'd</Badge>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Squads Tab */}
        <TabsContent value="squads" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Squad History
              </CardTitle>
              <CardDescription>Squads you've organized and joined</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="member">
                <TabsList className="mb-4">
                  <TabsTrigger value="member">Member</TabsTrigger>
                  <TabsTrigger value="organizer">Organizer</TabsTrigger>
                </TabsList>

                <TabsContent value="member" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-md border">
                        <div className="h-12 w-12 rounded-md bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white font-bold">
                          S{i}
                        </div>
                        <div>
                          <div className="font-medium">San Francisco UX Designers</div>
                          <div className="text-xs text-muted-foreground">15 members • 3 upcoming events</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="organizer" className="space-y-4">
                  <div className="text-center py-8 text-muted-foreground">
                    <div className="mb-2">You haven't organized any squads yet</div>
                    <Button>Create a Squad</Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Connections Tab */}
        <TabsContent value="connections" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Social Connections
              </CardTitle>
              <CardDescription>Friends and organizers you follow</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="friends">
                <TabsList className="mb-4">
                  <TabsTrigger value="friends">Friends</TabsTrigger>
                  <TabsTrigger value="organizers">Organizers</TabsTrigger>
                </TabsList>

                <TabsContent value="friends" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-md border">
                        <Avatar>
                          <AvatarImage src={`/placeholder.svg?height=40&width=40&text=F${i}`} />
                          <AvatarFallback>F{i}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Friend {i}</div>
                          <div className="text-xs text-muted-foreground">UX Designer</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="organizers" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-md border">
                        <Avatar>
                          <AvatarImage src={`/placeholder.svg?height=40&width=40&text=O${i}`} />
                          <AvatarFallback>O{i}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Organizer {i}</div>
                          <div className="text-xs text-muted-foreground">Tech Events</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Photos Tab */}
        <TabsContent value="photos" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Camera className="h-5 w-5 mr-2" />
                Photo Albums
              </CardTitle>
              <CardDescription>Photos from hangouts and events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-medium">Recent Photos</h4>
                <Button variant="outline" size="sm">
                  <Upload className="h-4 w-4 mr-1" />
                  Upload Photos
                </Button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <div key={i} className="aspect-square rounded-md bg-gray-100 relative group">
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <Button variant="ghost" size="icon" className="text-white">
                        <Star className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <h4 className="font-medium mb-4">Tagged Photos</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="aspect-square rounded-md bg-gray-100 relative group">
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all"></div>
                      <div className="absolute bottom-2 left-2 text-xs bg-black/50 text-white px-2 py-1 rounded-full">
                        Tagged by Friend {i}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
